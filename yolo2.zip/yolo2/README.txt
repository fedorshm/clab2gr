1. Разархивировать папку yolo
2. Перейти в папку yolo в терминале
3. Создать виртуальную среду (например python3 -m venv myappenv)
4. Активировать среду (source myappenv/bin/activate)
5. Установить библиотеки (pip install -r requirements.txt)
6. Запустить сервис командой streamlit run app.py
